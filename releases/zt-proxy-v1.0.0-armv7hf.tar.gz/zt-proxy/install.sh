#!/bin/sh
# zt-proxy installer for JetKVM
# Restricts WebUI to ZeroTier interface only
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ZT_IP="10.107.107.245"   # <-- your ZeroTier IP, change if needed
ZT_IFACE="zt_jetkvm"
PROXY_BIN=/userdata/bin/zt-proxy
KVM_CONFIG=/userdata/kvm_config.json

echo ""
echo "==> [1/4] Installing zt-proxy binary..."
cp "$SCRIPT_DIR/zt-proxy" "$PROXY_BIN"
chmod +x "$PROXY_BIN"
echo "    Installed: $PROXY_BIN"

echo ""
echo "==> [2/4] Installing init script..."
cat > /etc/init.d/S51zt-proxy << INITEOF
#!/bin/sh
ZT_IP=$ZT_IP
PROXY_BIN=$PROXY_BIN

case "\$1" in
  start)
    echo "Starting zt-proxy..."
    # Wait for ZeroTier interface to be up
    for i in \$(seq 1 30); do
      ip addr show $ZT_IFACE 2>/dev/null | grep -q "$ZT_IP" && break
      sleep 1
    done
    start-stop-daemon -S -b -x "\$PROXY_BIN" -- -listen "\$ZT_IP:80" -target "127.0.0.1:80"
    ;;
  stop)
    echo "Stopping zt-proxy..."
    start-stop-daemon -K -x "\$PROXY_BIN" 2>/dev/null || killall zt-proxy 2>/dev/null || true
    ;;
  restart)
    \$0 stop; sleep 1; \$0 start
    ;;
  *)
    echo "Usage: \$0 {start|stop|restart}"
    exit 1
    ;;
esac
INITEOF
chmod +x /etc/init.d/S51zt-proxy
cp /etc/init.d/S51zt-proxy /userdata/bin/S51zt-proxy

echo ""
echo "==> [3/4] Setting JetKVM WebUI to loopback-only..."
cp "$KVM_CONFIG" "${KVM_CONFIG}.bak.ztproxy"
sed -i 's/"local_loopback_only": false/"local_loopback_only": true/' "$KVM_CONFIG"
grep local_loopback "$KVM_CONFIG"

echo ""
echo "==> [4/4] Restarting JetKVM app..."
killall jetkvm_app 2>/dev/null || true
sleep 2
start-stop-daemon -S -b -x /userdata/jetkvm/bin/jetkvm_app

echo ""
echo "==> Starting zt-proxy..."
/etc/init.d/S51zt-proxy start
sleep 2

echo ""
echo "=========================================="
echo " Done!"
echo "=========================================="
echo ""
echo "  WebUI is now only accessible via ZeroTier:"
echo "    http://$ZT_IP"
echo ""
echo "  LAN access to port 80 is no longer available."
echo ""
echo "  After a firmware update, restore with:"
echo "    sh /userdata/bin/zt-reinstall.sh"
echo ""
