#!/bin/sh
# ZeroTier installer for JetKVM (ARMv7 hard-float, static binary)
# Idempotent — safe to re-run after firmware updates.
# Run from the directory containing this script and the zerotier-one binary.

set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

ZT_BIN_SRC="$SCRIPT_DIR/zerotier-one"
ZT_INSTALL=/userdata/bin/zerotier-one
ZT_HOME=/userdata/zerotier-one-data
ZT_STORED_BIN=/userdata/bin/zerotier-one  # persistent copy survives firmware updates

echo ""
echo "==> [1/5] Stopping any running ZeroTier..."
start-stop-daemon -K -x "$ZT_INSTALL" 2>/dev/null || killall zerotier-one 2>/dev/null || true
sleep 1

echo ""
echo "==> [2/5] Installing binary..."
mkdir -p /userdata/bin
cp "$ZT_BIN_SRC" "$ZT_INSTALL"
chmod +x "$ZT_INSTALL"
ln -sf "$ZT_INSTALL" /userdata/bin/zerotier-cli
ln -sf "$ZT_INSTALL" /userdata/bin/zerotier-idtool
echo "    Installed: $ZT_INSTALL ($(ls -lh "$ZT_INSTALL" | awk '{print $5}'))"

echo ""
echo "==> [3/5] Creating data directory..."
mkdir -p "$ZT_HOME"

echo ""
echo "==> [4/5] Ensuring TUN is available..."
modprobe tun 2>/dev/null || true
ls /sys/module/tun > /dev/null 2>&1 && echo "    TUN: OK" || echo "    WARNING: TUN module not loaded!"

echo ""
echo "==> [5/5] Installing init script..."

# Write the init script to /etc/init.d (active, runs at boot)
cat > /etc/init.d/S50zerotier << 'INITEOF'
#!/bin/sh
ZT_HOME=/userdata/zerotier-one-data
ZT_BIN=/userdata/bin/zerotier-one

case "$1" in
  start)
    echo "Starting ZeroTier..."
    modprobe tun 2>/dev/null || true
    start-stop-daemon -S -b -x "$ZT_BIN" -- "$ZT_HOME"
    ;;
  stop)
    echo "Stopping ZeroTier..."
    start-stop-daemon -K -x "$ZT_BIN" 2>/dev/null || killall zerotier-one 2>/dev/null || true
    ;;
  restart)
    $0 stop
    sleep 1
    $0 start
    ;;
  status)
    /userdata/bin/zerotier-cli -D/userdata/zerotier-one-data status
    /userdata/bin/zerotier-cli -D/userdata/zerotier-one-data listnetworks
    ;;
  *)
    echo "Usage: $0 {start|stop|restart|status}"
    exit 1
    ;;
esac
INITEOF
chmod +x /etc/init.d/S50zerotier

# Also store a persistent copy on /userdata so it can reinstall itself
# after a firmware update wipes /etc/init.d
cp /etc/init.d/S50zerotier /userdata/bin/S50zerotier
chmod +x /userdata/bin/S50zerotier

echo ""
echo "    Writing post-firmware-update reinstall script to /userdata/bin/zt-reinstall.sh..."
cat > /userdata/bin/zt-reinstall.sh << 'REINSTALLEOF'
#!/bin/sh
# Run this after a firmware update to restore ZeroTier init script.
# The binary and data dir on /userdata are untouched by firmware updates.
echo "==> Restoring ZeroTier init script..."
cp /userdata/bin/S50zerotier /etc/init.d/S50zerotier
chmod +x /etc/init.d/S50zerotier
echo "==> Starting ZeroTier..."
/etc/init.d/S50zerotier start
sleep 3
/userdata/bin/zerotier-cli -D/userdata/zerotier-one-data status
echo "Done. Run 'zerotier-cli -D/userdata/zerotier-one-data listnetworks' to check networks."
REINSTALLEOF
chmod +x /userdata/bin/zt-reinstall.sh

echo ""
echo "=========================================="
echo " Done! Next steps:"
echo "=========================================="
echo ""
echo "  1. Start ZeroTier:"
echo "       /etc/init.d/S50zerotier start"
echo ""
echo "  2. Check status:"
echo "       /userdata/bin/zerotier-cli -D$ZT_HOME status"
echo ""
echo "  3. Join your network:"
echo "       /userdata/bin/zerotier-cli -D$ZT_HOME join <network-id>"
echo ""
echo "  4. Authorize at https://my.zerotier.com"
echo ""
echo "  After a firmware update, restore with:"
echo "       sh /userdata/bin/zt-reinstall.sh"
echo ""
echo "  Tip: add to PATH:"
echo "       export PATH=\$PATH:/userdata/bin"
echo ""
